#!/bin/bash

LIMIT=8
while true ; do
  TIME=$(date '+%b %e %H')     #example: Apr 11 11
  BLOCK_IP=$(grep "$TIME" /var/log/auth.log|grep Failed|awk '{print $(NF-3)}'|sort|uniq -c|awk '$1>"$LIMIT"{print $1":"$2}')
  for i in $BLOCK_IP
  do
    IP=$(echo $i|awk -F: '{print $2}')
    grep $IP /etc/hosts.deny > /dev/null
    if [ $? -gt 0 ];
    then
      echo "sshd:$IP" >> /etc/hosts.deny
    fi
  done
  sleep 60
done